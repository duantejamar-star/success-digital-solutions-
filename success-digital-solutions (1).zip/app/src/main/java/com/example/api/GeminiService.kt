package com.example.api

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

data class GeminiRequest(
    val contents: List<Content>,
    val systemInstruction: Content? = null
)

data class Content(
    val parts: List<Part>
)

data class Part(
    val text: String
)

data class GeminiResponse(
    val candidates: List<Candidate>?
)

data class Candidate(
    val content: Content?
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val apiService: GeminiApiService by lazy {
        retrofit.create(GeminiApiService::class.java)
    }

    suspend fun getCyberSecurityAdvice(prompt: String, contextHistory: List<Content> = emptyList()): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return "Notice: Gemini API Key is currently unconfigured. To enable the AI Cybersecurity Advisor, please enter your GEMINI_API_KEY in the Secrets panel."
        }

        val systemPrompt = """
            You are Aegis AI, the virtual cybersecurity intelligence system representing Marcus Vance, a freelance cybersecurity specialist. 
            Your role is to offer highly accurate, professional, enterprise-grade security advice, code scanning feedback, and vulnerability analysis.
            Never reveal any confidential client information. 
            Always emphasize industry standards such as OWASP Top 10, NIST, and ISO 27001. 
            Maintain a secure, confident, professional, and slightly futuristic tone. 
            If the user asks about booking, remind them to use the 'Connect' tab to schedule a direct consulting meeting.
        """.trimIndent()

        // Combine history + new prompt
        val fullContents = contextHistory + Content(parts = listOf(Part(text = prompt)))
        val request = GeminiRequest(
            contents = fullContents,
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
        )

        return try {
            val response = apiService.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "No threats detected. System secure."
        } catch (e: Exception) {
            "Advisor Offline: ${e.localizedMessage ?: "Network anomaly detected."}"
        }
    }
}
