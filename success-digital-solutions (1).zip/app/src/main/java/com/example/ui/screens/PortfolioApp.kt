package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.*
import com.example.viewmodel.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortfolioApp(viewModel: PortfolioViewModel) {
    var isDarkTheme by remember { mutableStateOf(true) }

    MyApplicationTheme(darkTheme = isDarkTheme) {
        val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
        var currentTab by remember { mutableStateOf("dashboard") }
        var isSearching by remember { mutableStateOf(false) }
        val searchQuery by viewModel.searchQuery.collectAsState()

        val onBgColor = MaterialTheme.colorScheme.onBackground
        val primaryColor = MaterialTheme.colorScheme.primary

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        if (isSearching) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { viewModel.updateSearchQuery(it) },
                                placeholder = { Text("Search secure portal...", color = if (isDarkTheme) TextGray else Color(0xFF475569), fontSize = 12.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .padding(horizontal = 4.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(color = onBgColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace),
                                singleLine = true,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search",
                                        tint = primaryColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                trailingIcon = {
                                    IconButton(onClick = {
                                        viewModel.updateSearchQuery("")
                                        isSearching = false
                                    }) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Close Search",
                                            tint = onBgColor,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryColor,
                                    unfocusedBorderColor = onBgColor.copy(alpha = 0.15f),
                                    focusedContainerColor = onBgColor.copy(alpha = 0.03f),
                                    unfocusedContainerColor = onBgColor.copy(alpha = 0.03f),
                                    cursorColor = primaryColor
                                ),
                                shape = RoundedCornerShape(24.dp)
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(primaryColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Security,
                                        contentDescription = "Shield",
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Row {
                                    Text(
                                        text = "AEGIS",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = onBgColor,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = "SECURE",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = primaryColor,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.95f),
                        titleContentColor = onBgColor
                    ),
                    actions = {
                        if (!isSearching) {
                            IconButton(onClick = { isSearching = true }) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search Portal",
                                    tint = onBgColor
                                )
                            }

                            // Dynamic Theme Toggle Button
                            IconButton(onClick = { isDarkTheme = !isDarkTheme }) {
                                Icon(
                                    imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = "Toggle Theme Mode",
                                    tint = primaryColor
                                )
                            }
                            
                            // Operational Status Indicator
                            Row(
                                modifier = Modifier.padding(end = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(GridGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SECURE",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = GridGreen,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                )
            },
        bottomBar = {
            PortfolioBottomBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .drawBehind {
                    // Left-top cyan glow
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(CyberCyan.copy(alpha = 0.08f), Color.Transparent),
                            center = Offset(0f, 0f),
                            radius = size.width * 0.7f
                        ),
                        radius = size.width * 0.7f,
                        center = Offset(0f, 0f)
                    )
                    // Right-bottom blue glow
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(CyberBlue.copy(alpha = 0.06f), Color.Transparent),
                            center = Offset(size.width, size.height),
                            radius = size.width * 0.8f
                        ),
                        radius = size.width * 0.8f,
                        center = Offset(size.width, size.height)
                    )
                }
                .background(DarkBackground)
        ) {
            // Animated scanner grid overlay
            CyberBackgroundGrid()

            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                },
                label = "MainTabs"
            ) { targetTab ->
                when (targetTab) {
                    "dashboard" -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToTab = { currentTab = it }
                    )
                    "skills_bio" -> SkillsBioScreen(viewModel = viewModel)
                    "ai_advisor" -> AIShieldScreen(viewModel = viewModel)
                    "connect" -> ConnectScreen(viewModel = viewModel)
                }
            }
        }
    }
}
}

@Composable
fun CyberBackgroundGrid() {
    // Elegant Canvas drawing a cyber grid and glowing matrix-inspired elements
    val infiniteTransition = rememberInfiniteTransition(label = "cyber_grid")
    val scanlineY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline"
    )

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                // Drawing horizontal lines
                val gridSpacing = 60.dp.toPx()
                val totalWidth = size.width
                val totalHeight = size.height

                // Subtle grid
                for (x in 0 until (totalWidth / gridSpacing).toInt() + 1) {
                    drawLine(
                        color = SurfaceBorder.copy(alpha = 0.12f),
                        start = Offset(x * gridSpacing, 0f),
                        end = Offset(x * gridSpacing, totalHeight),
                        strokeWidth = 1f
                    )
                }
                for (y in 0 until (totalHeight / gridSpacing).toInt() + 1) {
                    drawLine(
                        color = SurfaceBorder.copy(alpha = 0.12f),
                        start = Offset(0f, y * gridSpacing),
                        end = Offset(totalWidth, y * gridSpacing),
                        strokeWidth = 1f
                    )
                }

                // Scrolling neon scanline
                drawLine(
                    color = CyberCyan.copy(alpha = 0.15f),
                    start = Offset(0f, scanlineY),
                    end = Offset(totalWidth, scanlineY),
                    strokeWidth = 2.dp.toPx()
                )
            }
    ) {
        // No-op
    }
}

@Composable
fun PortfolioBottomBar(
    currentTab: String,
    onTabSelected: (String) -> Unit
) {
    NavigationBar(
        containerColor = DarkSurface.copy(alpha = 0.85f),
        tonalElevation = 0.dp,
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp, top = 4.dp)
            .border(width = 1.dp, color = Color.White.copy(alpha = 0.10f), shape = RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
    ) {
        NavigationBarItem(
            selected = currentTab == "dashboard",
            onClick = { onTabSelected("dashboard") },
            label = { Text("Home", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberCyan,
                selectedTextColor = CyberCyan,
                indicatorColor = CyberCyan.copy(alpha = 0.15f),
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_home")
        )

        NavigationBarItem(
            selected = currentTab == "skills_bio",
            onClick = { onTabSelected("skills_bio") },
            label = { Text("Expertise", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            icon = { Icon(Icons.Filled.Code, contentDescription = "Expertise") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberCyan,
                selectedTextColor = CyberCyan,
                indicatorColor = CyberCyan.copy(alpha = 0.15f),
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_expertise")
        )

        NavigationBarItem(
            selected = currentTab == "ai_advisor",
            onClick = { onTabSelected("ai_advisor") },
            label = { Text("AI Advisor", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            icon = { Icon(Icons.Filled.Psychology, contentDescription = "AI Advisor") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberCyan,
                selectedTextColor = CyberCyan,
                indicatorColor = CyberCyan.copy(alpha = 0.15f),
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_ai")
        )

        NavigationBarItem(
            selected = currentTab == "connect",
            onClick = { onTabSelected("connect") },
            label = { Text("Connect", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            icon = { Icon(Icons.Filled.CalendarMonth, contentDescription = "Connect") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberCyan,
                selectedTextColor = CyberCyan,
                indicatorColor = CyberCyan.copy(alpha = 0.15f),
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_connect")
        )
    }
}

// ==================== DASHBOARD (HOME) SCREEN ====================
@Composable
fun DashboardScreen(
    viewModel: PortfolioViewModel,
    onNavigateToTab: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val searchQuery by viewModel.searchQuery.collectAsState()

    val filteredServices = remember(searchQuery) {
        if (searchQuery.isEmpty()) {
            viewModel.services
        } else {
            viewModel.services.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.description.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    val filteredBlogPosts = remember(searchQuery) {
        if (searchQuery.isEmpty()) {
            viewModel.blogPosts
        } else {
            viewModel.blogPosts.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.excerpt.contains(searchQuery, ignoreCase = true) ||
                it.tag.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Hero Section Background Image & Overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_banner),
                contentDescription = "Cyber Hero Banner",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Neon Gradient overlay on image
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, DarkBackground.copy(alpha = 0.5f), DarkBackground),
                            startY = 0f,
                            endY = 1000f
                        )
                    )
            )

            // Overlap Glass Header Content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .background(CyberCyan.copy(alpha = 0.10f), CircleShape)
                        .border(1.dp, CyberCyan.copy(alpha = 0.20f), CircleShape)
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(CyberCyan)
                    )
                    Text(
                        text = "SECURE INFRASTRUCTURE EXPERT",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Protecting Businesses from Modern Cyber Threats.",
                    style = androidx.compose.ui.text.TextStyle(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color.White, CyberCyan, CyberBlue)
                        )
                    ),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 30.sp
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Quick Bio Lead-in
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.8f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "FREELANCE CYBERSECURITY SPECIALIST",
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "I'm Marcus Vance, an Offensive Security specialist and cloud defense architect. I design bespoke protection maps, simulate sophisticated attacks, and audit core code repositories for SMEs, startups, and healthcare firms globally.",
                        color = TextGray,
                        fontSize = 14.sp,
                        lineHeight = 21.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Call to actions - Sleek Interface rounded grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { onNavigateToTab("connect") },
                            modifier = Modifier
                                .weight(1f)
                                .height(80.dp)
                                .testTag("book_consultation_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.White),
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(Icons.Filled.EventAvailable, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Book Consultation", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Button(
                            onClick = { onNavigateToTab("ai_advisor") },
                            modifier = Modifier
                                .weight(1f)
                                .height(80.dp)
                                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
                                .testTag("quick_assessment_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White.copy(alpha = 0.05f),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(Icons.Filled.Analytics, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Get Assessment", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Services Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "DEFENSIVE & OFFENSIVE SERVICES",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                    color = CyberBlue,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "10 Modules",
                    fontSize = 11.sp,
                    color = TextGray,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(12.dp))

            // Scrollable Grid of Services
            if (filteredServices.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .border(1.dp, CyberCyan.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "[ERROR: SECURE REGISTRY EMPTY]",
                            color = Color.Red,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No active modules found matching \"$searchQuery\". Try another keyword.",
                            color = TextGray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                filteredServices.forEach { service ->
                    ServiceCard(service = service)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Professional Security Tools Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "PROFESSIONAL SECURITY TOOLS",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "3 Key Utilities",
                    fontSize = 11.sp,
                    color = TextGray,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(12.dp))

            ToolCard(
                name = "Nmap",
                description = "Advanced network exploration, host discovery, and port auditing. Essential for mapping attack surfaces and detecting active services.",
                usageTag = "Network Scanning & Discovery"
            )
            Spacer(modifier = Modifier.height(10.dp))

            ToolCard(
                name = "Burp Suite",
                description = "Web application penetration testing and API traffic interception. Used for payload fuzzing, session hijacking simulation, and OWASP audit validation.",
                usageTag = "Web App & API Auditing"
            )
            Spacer(modifier = Modifier.height(10.dp))

            ToolCard(
                name = "Metasploit",
                description = "Modular exploitation framework for vulnerability verification. Essential for launching mock payloads and proving access vulnerability severity.",
                usageTag = "Exploitation & Validation"
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Interactive Vulnerability Live Feed (Fake Security Blog Teaser)
            Text(
                text = "THREAT INTEL & ADVISORIES",
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (filteredBlogPosts.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .border(1.dp, CyberCyan.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "[WARN: INTEL STREAM OFFLINE]",
                            color = CyberCyan,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No published advisories matching \"$searchQuery\". Try another security filter.",
                            color = TextGray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                filteredBlogPosts.forEach { blog ->
                    BlogTeaserCard(blog = blog)
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            LiveVulnerabilityFeedSection()

            Spacer(modifier = Modifier.height(24.dp))

            // Testimonials
            Text(
                text = "TRUSTED BY ENTERPRISES",
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                color = ElectricBlue,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(viewModel.testimonials) { testimonial ->
                    TestimonialCard(testimonial = testimonial)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Footer info
            Divider(color = SurfaceBorder)
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = "Verified SEC",
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "NIST Alignment • ISO 27001 • OWASP Top 10",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = TextGray
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "© 2026 Marcus Vance Cybersecurity Consulting. All rights reserved.",
                    fontSize = 10.sp,
                    color = TextGray.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Privacy Policy",
                        fontSize = 10.sp,
                        color = CyberCyan.copy(alpha = 0.8f),
                        modifier = Modifier.clickable {
                            Toast.makeText(context, "AES-256 standard policy active.", Toast.LENGTH_SHORT).show()
                        }
                    )
                    Text(
                        text = "|",
                        fontSize = 10.sp,
                        color = TextGray
                    )
                    Text(
                        text = "Terms of Service",
                        fontSize = 10.sp,
                        color = CyberCyan.copy(alpha = 0.8f),
                        modifier = Modifier.clickable {
                            Toast.makeText(context, "Consulting terms apply.", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun ServiceCard(service: ServiceItem) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        onClick = { expanded = !expanded },
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (expanded) CyberCyan else SurfaceBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.85f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Custom Icon based on item
                    val icon = when (service.iconName) {
                        "bug_report" -> Icons.Filled.BugReport
                        "security" -> Icons.Filled.Shield
                        "web" -> Icons.Filled.Web
                        "lan" -> Icons.Filled.SettingsEthernet
                        "cloud" -> Icons.Filled.Cloud
                        "fact_check" -> Icons.Filled.FactCheck
                        "school" -> Icons.Filled.School
                        "crisis_alert" -> Icons.Filled.CrisisAlert
                        "api" -> Icons.Filled.Api
                        else -> Icons.Filled.Forum
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberCyan.copy(alpha = 0.1f))
                            .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = service.title,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = service.category,
                            color = TextGray,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Icon(
                    imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = TextGray,
                    modifier = Modifier.size(20.dp)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = SurfaceBorder.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = service.description,
                        color = IceWhite,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Standard compliance: OWASP Top 10 • NIST v2.0 • ISO 27001",
                        fontSize = 10.sp,
                        color = CyberBlue,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun ToolCard(name: String, description: String, usageTag: String) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        onClick = { expanded = !expanded },
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (expanded) CyberCyan else SurfaceBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.85f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    val icon = when (name.lowercase()) {
                        "nmap" -> Icons.Filled.SettingsEthernet
                        "burp suite" -> Icons.Filled.Web
                        "metasploit" -> Icons.Filled.BugReport
                        else -> Icons.Filled.Build
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberCyan.copy(alpha = 0.1f))
                            .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = name,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Usage: $usageTag",
                            color = CyberBlue,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Icon(
                    imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = TextGray,
                    modifier = Modifier.size(20.dp)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = SurfaceBorder.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = description,
                        color = IceWhite,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tool Deployment Type: Technical Audits • Vulnerability Scans",
                        fontSize = 10.sp,
                        color = CyberCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun BlogTeaserCard(blog: BlogItem) {
    var showDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showDialog = true }
            .border(1.dp, SurfaceBorder.copy(alpha = 0.8f), RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.7f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(ElectricBlue.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = blog.tag.uppercase(),
                        color = CyberBlue,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = blog.readTime,
                    fontSize = 10.sp,
                    color = TextGray,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = blog.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = blog.excerpt,
                color = TextGray,
                fontSize = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Close Advisement", color = CyberCyan, fontFamily = FontFamily.Monospace)
                }
            },
            title = {
                Column {
                    Text(
                        text = "ADVISORY WRITEOUT",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = blog.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "Published on: ${blog.publishedDate}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextGray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = blog.fullText,
                        color = IceWhite,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.border(1.dp, CyberCyan, RoundedCornerShape(12.dp))
        )
    }
}

@Composable
fun TestimonialCard(testimonial: TestimonialItem) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .border(1.dp, SurfaceBorder.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Icon(
                    imageVector = Icons.Filled.FormatQuote,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "\"${testimonial.quote}\"",
                    color = IceWhite,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(CyberCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = testimonial.author.take(1),
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = testimonial.author,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${testimonial.authorTitle}, ${testimonial.company}",
                        color = TextGray,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// ==================== EXPERTISE & SKILLS SCREEN ====================
@Composable
fun SkillsBioScreen(viewModel: PortfolioViewModel) {
    val scrollState = rememberScrollState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val filteredProjects = remember(searchQuery) {
        if (searchQuery.isEmpty()) {
            viewModel.projects
        } else {
            viewModel.projects.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.objective.contains(searchQuery, ignoreCase = true) ||
                it.tags.any { tag -> tag.contains(searchQuery, ignoreCase = true) }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Bio Header Card with generated profile avatar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.8f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_profile_avatar),
                    contentDescription = "Marcus Vance Profile",
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, CyberCyan, RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Marcus Vance",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Ethical Hacker & Consultant",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = GridGreen, modifier = Modifier.size(16.dp))
                        Text("OSCP • CISSP", color = TextGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Philosophy & Values
        Text(
            text = "SECURITY PHILOSOPHY",
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Effective security is never a static target. It is a continuous process of proactive auditing, relentless threat-hunting, and comprehensive employee empowerment. I construct zero-trust defensive ecosystems based on actual offensive intelligence.",
            color = TextGray,
            fontSize = 13.sp,
            lineHeight = 19.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Skills Section (Progress bars)
        Text(
            text = "TECHNICAL SKILL MATRIX",
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Group skills by category
        val categories = viewModel.skills.groupBy { it.category }
        categories.forEach { (cat, items) ->
            Text(
                text = "[$cat Modules]",
                fontFamily = FontFamily.Monospace,
                color = ElectricBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            items.forEach { skill ->
                SkillBar(skill = skill)
                Spacer(modifier = Modifier.height(10.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Case Studies & Projects
        Text(
            text = "CASE STUDIES",
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (filteredProjects.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(1.dp, CyberCyan.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "[ERROR: NO CASE STUDIES RETRIEVED]",
                        color = Color.Red,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "No recorded operations match \"$searchQuery\". Try adjusting your filters.",
                        color = TextGray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            filteredProjects.forEach { project ->
                ProjectCard(project = project)
                Spacer(modifier = Modifier.height(14.dp))
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Certifications Grid Section
        Text(
            text = "SECURITY CERTIFICATIONS",
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Validated professional credentials confirming expert capability in offensive penetration testing and defensive architecture.",
            color = TextGray,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )
        Spacer(modifier = Modifier.height(14.dp))

        val certChunks = viewModel.certifications.chunked(2)
        certChunks.forEach { chunk ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                chunk.forEach { cert ->
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.8f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(cert.badgeColor)).copy(alpha = 0.1f))
                                    .border(1.dp, Color(android.graphics.Color.parseColor(cert.badgeColor)).copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (cert.title) {
                                        "OSCP" -> Icons.Filled.VerifiedUser
                                        "CISSP" -> Icons.Filled.Shield
                                        "CEH Master" -> Icons.Filled.BugReport
                                        else -> Icons.Filled.Cloud
                                    },
                                    contentDescription = null,
                                    tint = Color(android.graphics.Color.parseColor(cert.badgeColor)),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = cert.title,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = cert.issuer,
                                color = TextGray,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .background(SurfaceBorder.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = cert.id,
                                    color = CyberCyan.copy(alpha = 0.8f),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
                if (chunk.size < 2) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Glossary Section
        Text(
            text = "CYBERSECURITY GLOSSARY",
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Understanding core terminology helps demystify security metrics and empowers your business decisions. Tap any term to expand.",
            color = TextGray,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        viewModel.glossary.forEach { glossaryItem ->
            GlossaryCard(item = glossaryItem)
            Spacer(modifier = Modifier.height(10.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun GlossaryCard(item: com.example.viewmodel.GlossaryItem) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        onClick = { isExpanded = !isExpanded },
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isExpanded) CyberCyan else SurfaceBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.8f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberCyan.copy(alpha = 0.1f))
                            .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MenuBook,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = item.term,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = TextGray,
                    modifier = Modifier.size(20.dp)
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = SurfaceBorder.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Definition",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = item.definition,
                        color = IceWhite,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Business Impact & Value",
                        color = CyberBlue,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = item.impact,
                        color = TextGray,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SkillBar(skill: SkillItem) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = skill.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(
                text = "${(skill.level * 100).toInt()}%",
                color = CyberCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape)
                .background(SurfaceBorder.copy(alpha = 0.5f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(skill.level)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(ElectricBlue, CyberCyan)
                        )
                    )
            )
        }
    }
}

@Composable
fun ProjectCard(project: ProjectItem) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        onClick = { isExpanded = !isExpanded },
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isExpanded) CyberCyan else SurfaceBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.8f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = project.title,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = TextGray,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                project.tags.forEach { tag ->
                    Box(
                        modifier = Modifier
                            .background(CyberCyan.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = tag,
                            color = CyberCyan,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = SurfaceBorder.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(text = "OBJECTIVE", color = CyberBlue, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text(text = project.objective, color = IceWhite, fontSize = 12.sp, lineHeight = 18.sp)
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "METHODOLOGY", color = CyberBlue, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text(text = project.methodology, color = IceWhite, fontSize = 12.sp, lineHeight = 18.sp)
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "OUTCOME", color = GridGreen, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text(text = project.outcome, color = IceWhite, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}


// ==================== INTERACTIVE AI SHIELD ADVISOR SCREEN ====================
@Composable
fun AIShieldScreen(viewModel: PortfolioViewModel) {
    var inputText by remember { mutableStateOf("") }
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isChatLoading by viewModel.isChatLoading.collectAsState()
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Auto-scroll to latest message
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // AI Header card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCyan, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.9f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(CyberCyan.copy(alpha = 0.15f))
                            .border(1.dp, CyberCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Psychology, contentDescription = "AI Core", tint = CyberCyan, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = "Aegis AI Threat Core", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(text = "Marcus's Automated Advisor (Gemini 3.5)", color = TextGray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Submit lines of code, request security advice, or verify a potential vulnerability. Try typing: 'How do I remediate SQL injection?'",
                    color = TextGray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat Bubble List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chatMessages) { msg ->
                val isUser = msg.sender == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 12.dp,
                                    topEnd = 12.dp,
                                    bottomStart = if (isUser) 12.dp else 2.dp,
                                    bottomEnd = if (isUser) 2.dp else 12.dp
                                )
                            )
                            .background(if (isUser) CyberCyan.copy(alpha = 0.12f) else DarkSurface)
                            .border(
                                1.dp,
                                if (isUser) CyberCyan.copy(alpha = 0.5f) else SurfaceBorder,
                                RoundedCornerShape(
                                    topStart = 12.dp,
                                    topEnd = 12.dp,
                                    bottomStart = if (isUser) 12.dp else 2.dp,
                                    bottomEnd = if (isUser) 2.dp else 12.dp
                                )
                            )
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isUser) "CONSULTANT CLIENT" else "AEGIS AI COGNITION",
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isUser) CyberBlue else CyberCyan,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = msg.timestamp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextGray,
                                    fontSize = 9.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = msg.text,
                                color = Color.White,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }
                    }
                }
            }

            if (isChatLoading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .border(1.dp, SurfaceBorder, RoundedCornerShape(8.dp)),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = CyberCyan,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Analyzing payload...",
                                    color = TextGray,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input Field Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Enter security query...", color = TextGray) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    disabledContainerColor = DarkSurface,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = CyberCyan,
                    unfocusedIndicatorColor = SurfaceBorder
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_input_text_field"),
                maxLines = 3
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        viewModel.sendChatMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberCyan)
                    .testTag("ai_send_button"),
                enabled = !isChatLoading
            ) {
                Icon(
                    imageVector = Icons.Filled.Send,
                    contentDescription = "Send",
                    tint = DarkBackground
                )
            }
        }
    }
}


// ==================== CONNECT (CONSULTATION) SCREEN ====================
@Composable
fun ConnectScreen(viewModel: PortfolioViewModel) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    // Local form states
    var clientName by remember { mutableStateOf("") }
    var clientEmail by remember { mutableStateOf("") }
    var selectedService by remember { mutableStateOf("Penetration Testing") }
    var isSubmittingBooking by remember { mutableStateOf(false) }

    // Contact state
    var contactName by remember { mutableStateOf("") }
    var contactEmail by remember { mutableStateOf("") }
    var contactMessage by remember { mutableStateOf("") }
    var isSubmittingContact by remember { mutableStateOf(false) }
    var contactError by remember { mutableStateOf<String?>(null) }
    var bookingError by remember { mutableStateOf<String?>(null) }

    // Subscriptions/bookings from VM
    val bookings by viewModel.bookings.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()
    val selectedTimeSlot by viewModel.selectedTimeSlot.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Main Booking Module Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCyan, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.9f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SCHEDULE A SECURITY CONSULTATION",
                    fontFamily = FontFamily.Monospace,
                    color = CyberCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Select a date and hour for a live 30-minute system assessment roadmap video call with Marcus Vance.",
                    color = TextGray,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Custom Day Selector (Calendar simulation)
                Text(
                    text = "1. CHOOSE DATE",
                    color = CyberBlue,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf(
                        "Tomorrow" to 1,
                        "In 2 Days" to 2,
                        "In 3 Days" to 3,
                        "In 4 Days" to 4
                    ).forEach { (label, offset) ->
                        val targetCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offset) }
                        val isSelected = selectedDate.get(Calendar.DAY_OF_YEAR) == targetCal.get(Calendar.DAY_OF_YEAR)
                        
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) CyberCyan else DarkBackground)
                                .border(1.dp, if (isSelected) CyberCyan else SurfaceBorder, RoundedCornerShape(6.dp))
                                .clickable { viewModel.changeBookingDate(offset) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = label,
                                    color = if (isSelected) DarkBackground else TextGray,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = SimpleDateFormat("MMM d", Locale.US).format(targetCal.time),
                                    color = if (isSelected) DarkBackground else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Time Slots Grid
                Text(
                    text = "2. CHOOSE TIME (UTC-7)",
                    color = CyberBlue,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(viewModel.timeSlots) { slot ->
                        val isSelected = selectedTimeSlot == slot
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else DarkBackground)
                                .border(1.dp, if (isSelected) CyberCyan else SurfaceBorder, RoundedCornerShape(6.dp))
                                .clickable { viewModel.selectTimeSlot(slot) }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = slot,
                                color = if (isSelected) CyberCyan else Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Credentials Inputs
                Text(
                    text = "3. BUSINESS DETAILS",
                    color = CyberBlue,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it },
                    label = { Text("Corporate Name", color = TextGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = SurfaceBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_name_field"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = clientEmail,
                    onValueChange = { clientEmail = it },
                    label = { Text("Contact Email", color = TextGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = SurfaceBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_email_field"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (bookingError != null) {
                    Text(
                        text = bookingError!!,
                        color = SoftRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Button(
                    onClick = {
                        val emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$".toRegex()
                        if (clientName.isBlank() || clientEmail.isBlank()) {
                            bookingError = "[ERROR: ALL FIELDS ARE MANDATORY]"
                        } else if (!emailRegex.matches(clientEmail.trim())) {
                            bookingError = "[ERROR: INVALID ENVELOPE ADDRESS/FORMAT]"
                        } else {
                            bookingError = null
                            isSubmittingBooking = true
                            val success = viewModel.submitBooking(clientName, clientEmail, selectedService)
                            if (success) {
                                Toast.makeText(context, "Consultation Slot Registered!", Toast.LENGTH_LONG).show()
                                clientName = ""
                                clientEmail = ""
                            } else {
                                bookingError = "[ERROR: SUBMISSION FAILED]"
                            }
                            isSubmittingBooking = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("booking_submit_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    shape = RoundedCornerShape(8.dp),
                    enabled = !isSubmittingBooking
                ) {
                    Text(
                        text = "RESERVE ASSESSMENT ROADMAP",
                        color = DarkBackground,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Display Active bookings if scheduled
        if (bookings.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "YOUR PLANNED SESSIONS",
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = GridGreen,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            bookings.forEach { bk ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GridGreen.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Assessment Roadmap Session", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = bk.dateString, color = TextGray, fontSize = 11.sp)
                            Text(text = "Slot: ${bk.timeSlot}", color = CyberCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        IconButton(onClick = { viewModel.clearBookings() }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Cancel", tint = SoftRed, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Direct General Contact Form
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.7f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SECURE GENERAL INQUIRY",
                    fontFamily = FontFamily.Monospace,
                    color = CyberBlue,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = contactName,
                    onValueChange = { contactName = it },
                    label = { Text("Full Name", color = TextGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = SurfaceBorder
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = contactEmail,
                    onValueChange = { contactEmail = it },
                    label = { Text("Secure Email Address", color = TextGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = SurfaceBorder
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = contactMessage,
                    onValueChange = { contactMessage = it },
                    label = { Text("Encryption / Security Requirements", color = TextGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = SurfaceBorder
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (contactError != null) {
                    Text(
                        text = contactError!!,
                        color = SoftRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Button(
                    onClick = {
                        val emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$".toRegex()
                        if (contactName.isBlank() || contactEmail.isBlank() || contactMessage.isBlank()) {
                            contactError = "[ERROR: ALL FIELDS ARE MANDATORY]"
                        } else if (!emailRegex.matches(contactEmail.trim())) {
                            contactError = "[ERROR: INVALID ENVELOPE ADDRESS/FORMAT]"
                        } else {
                            contactError = null
                            isSubmittingContact = true
                            val success = viewModel.submitContact(contactName, contactEmail, contactMessage)
                            if (success) {
                                Toast.makeText(context, "Secure message logged successfully!", Toast.LENGTH_SHORT).show()
                                contactName = ""
                                contactEmail = ""
                                contactMessage = ""
                            } else {
                                contactError = "[ERROR: SUBMISSION FAILED]"
                            }
                            isSubmittingContact = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberBlue),
                    shape = RoundedCornerShape(8.dp),
                    enabled = !isSubmittingContact
                ) {
                    Text(
                        text = "DISPATCH SECURE ENVELOPE",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Direct Social Connect Buttons
        Text(
            text = "DIRECT TRANSMISSION PROTOCOLS",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            color = CyberCyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        // WhatsApp direct button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF25D366))
                .clickable {
                    val urlIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/2348104905514?text=Hello%20Marcus,%20I'd%20like%20to%20request%20a%20security%20audit"))
                    context.startActivity(urlIntent)
                }
                .padding(14.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Phone, contentDescription = "WhatsApp", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CONNECT VIA WHATSAPP SECURE CHAT",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // LinkedIn
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurface)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(8.dp))
                    .clickable { uriHandler.openUri("https://linkedin.com/in/marcusvance-cyber") }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Link, contentDescription = "LinkedIn", tint = CyberCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("LinkedIn", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }

            // GitHub
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurface)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(8.dp))
                    .clickable { uriHandler.openUri("https://github.com/marcusvance-sec") }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Terminal, contentDescription = "GitHub", tint = CyberCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("GitHub Core", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
        Spacer(modifier = Modifier.height(30.dp))
    }
}

data class LiveRssItem(
    val title: String,
    val pubDate: String,
    val description: String,
    val link: String
)

@Composable
fun LiveVulnerabilityFeedSection() {
    var selectedSource by remember { mutableStateOf("CISA") }
    
    val cisaItems = listOf(
        LiveRssItem(
            title = "CISA Releases Advisory on Active Exploitation of Edge Routers",
            pubDate = "2026-07-06",
            link = "https://www.cisa.gov/news-events/alerts",
            description = "CISA has released a cybersecurity advisory addressing critical vulnerabilities in enterprise edge routing equipment being actively exploited by advanced persistent threat (APT) groups."
        ),
        LiveRssItem(
            title = "Securing Network Infrastructure: Key Mitigation Strategies",
            pubDate = "2026-07-02",
            link = "https://www.cisa.gov/news-events/alerts",
            description = "This joint advisory outlines tactical remediation guidelines for network administrators to lock down port infrastructure and enable granular logging schemas."
        ),
        LiveRssItem(
            title = "Malware Analysis Report: MAR-1048293-1.v1 BlackByte Ransomware",
            pubDate = "2026-06-28",
            link = "https://www.cisa.gov/news-events/alerts",
            description = "An analysis of the latest variants of the BlackByte ransomware family, detailing unique registry keys and lateral movement command sequences."
        )
    )

    val nistItems = listOf(
        LiveRssItem(
            title = "CVE-2026-10482: Critical Remote Code Execution in Web Framework",
            pubDate = "2026-07-05",
            link = "https://nvd.nist.gov/",
            description = "A deserialization flaw in the request deserializer allows unauthenticated remote attackers to achieve arbitrary code execution on host containers."
        ),
        LiveRssItem(
            title = "CVE-2026-39281: High Severity Privilege Escalation in Kernel Module",
            pubDate = "2026-07-01",
            link = "https://nvd.nist.gov/",
            description = "An integer overflow vulnerability in memory layout allocation functions permits local users to acquire elevated root credentials via raw block inputs."
        ),
        LiveRssItem(
            title = "CVE-2026-74829: Cross-Site Scripting (XSS) in Identity Provider",
            pubDate = "2026-06-27",
            link = "https://nvd.nist.gov/",
            description = "Reflected XSS exists in OAuth callback redirects, leading to token hijacking when unsuspecting administrators are lured onto malicious phishing flows."
        )
    )

    val currentItems = if (selectedSource == "CISA") cisaItems else nistItems

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(CyberCyan, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE RSS INTELLIGENCE FEED",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Vulnerability Reports",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 18.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            // Toggles
            Row(
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                    .padding(2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(if (selectedSource == "CISA") CyberCyan else Color.Transparent, RoundedCornerShape(6.dp))
                        .clickable { selectedSource = "CISA" }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "CISA",
                        color = if (selectedSource == "CISA") Color.Black else TextGray,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(2.dp))
                Box(
                    modifier = Modifier
                        .background(if (selectedSource == "NIST") CyberCyan else Color.Transparent, RoundedCornerShape(6.dp))
                        .clickable { selectedSource = "NIST" }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "NIST",
                        color = if (selectedSource == "NIST") Color.Black else TextGray,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        currentItems.forEach { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = item.pubDate,
                            color = TextGray,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .background(CyberCyan.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "OFFLINE SYNC",
                                color = CyberCyan,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = item.title,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = item.description,
                        color = TextGray,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

