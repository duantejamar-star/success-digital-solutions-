package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF06B6D4)     // cyan-500 (#06b6d4)
val CyberBlue = Color(0xFF3B82F6)     // blue-500 (#3b82f6)
val ElectricBlue = Color(0xFF2563EB)  // blue-600 (#2563eb)
val DarkBackground = Color(0xFF050810) // sleek deep background #050810
val DarkSurface = Color(0xFF101625)    // sleek card surface #101625
val SurfaceBorder = Color(0x1AFFFFFF)  // sleek border border-white/10
val IceWhite = Color(0xFFCBD5E1)       // slate-300 / slate-200 for clean text
val TextGray = Color(0xFF94A3B8)       // slate-400 for secondary text
val GridGreen = Color(0xFF10B981)      // emerald-500
val SoftRed = Color(0xFFEF4444)        // red-500
val CardOverlay = Color(0x1206B6D4)    // cyan-500/10
