package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val LocalIsDarkTheme = staticCompositionLocalOf { true }

private val CyberDarkColorScheme = darkColorScheme(
  primary = CyberCyan,
  secondary = CyberBlue,
  tertiary = ElectricBlue,
  background = DarkBackground,
  surface = DarkSurface,
  onPrimary = DarkBackground,
  onSecondary = IceWhite,
  onTertiary = IceWhite,
  onBackground = IceWhite,
  onSurface = IceWhite,
  outline = SurfaceBorder
)

private val HighContrastLightColorScheme = lightColorScheme(
  primary = Color(0xFF0891B2),      // High-contrast deep cyan
  secondary = Color(0xFF1E3A8A),    // Deep navy/blue
  tertiary = Color(0xFF1E293B),     // Slate 800
  background = Color(0xFFFFFFFF),   // Clean high-contrast white
  surface = Color(0xFFF1F5F9),      // Slate 100 for surface cards
  onPrimary = Color(0xFFFFFFFF),
  onSecondary = Color(0xFFFFFFFF),
  onTertiary = Color(0xFFFFFFFF),
  onBackground = Color(0xFF0F172A), // Very dark slate for absolute readability
  onSurface = Color(0xFF0F172A),
  outline = Color(0x330F172A)       // Slate border 20% opacity
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) CyberDarkColorScheme else HighContrastLightColorScheme

  CompositionLocalProvider(LocalIsDarkTheme provides darkTheme) {
    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
  }
}
