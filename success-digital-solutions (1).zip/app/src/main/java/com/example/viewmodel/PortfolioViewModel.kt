package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.Content
import com.example.api.GeminiClient
import com.example.api.Part
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// --- Data Models ---
data class GlossaryItem(
    val term: String,
    val definition: String,
    val impact: String
)

data class ServiceItem(
    val title: String,
    val description: String,
    val iconName: String,
    val category: String
)

data class SkillItem(
    val name: String,
    val level: Float, // 0f to 1f
    val category: String
)

data class ProjectItem(
    val title: String,
    val objective: String,
    val methodology: String,
    val outcome: String,
    val tags: List<String>
)

data class CertificationItem(
    val title: String,
    val issuer: String,
    val badgeColor: String,
    val id: String
)

data class TestimonialItem(
    val quote: String,
    val author: String,
    val company: String,
    val authorTitle: String
)

data class BlogItem(
    val id: String,
    val title: String,
    val excerpt: String,
    val readTime: String,
    val tag: String,
    val fullText: String,
    val publishedDate: String
)

data class BookingItem(
    val id: String,
    val dateString: String,
    val timeSlot: String,
    val clientName: String,
    val clientEmail: String,
    val serviceRequested: String
)

data class ContactSubmission(
    val id: String,
    val name: String,
    val email: String,
    val message: String,
    val timestamp: String
)

data class ChatMessage(
    val sender: String, // "user" or "advisor"
    val text: String,
    val timestamp: String
)

class PortfolioViewModel : ViewModel() {

    val glossary = listOf(
        GlossaryItem(
            term = "Zero-Trust",
            definition = "A security model based on the premise of 'never trust, always verify'. Every request for access to any system must be authenticated, authorized, and encrypted, regardless of whether it originates inside or outside the network perimeter.",
            impact = "Ensures that even if an attacker gains access to one account or device, they cannot move freely through the rest of your systems."
        ),
        GlossaryItem(
            term = "Penetration Testing",
            definition = "An authorized, simulated cyberattack against your computer system, network, or web applications to identify vulnerabilities that attackers could exploit. Think of it as hiring an expert to try breaking into your safe to test its lock.",
            impact = "Identifies weak points in your defenses before malicious hackers find them, providing a detailed map for patching and hardening."
        ),
        GlossaryItem(
            term = "Fuzzing",
            definition = "An automated software testing technique that involves providing invalid, unexpected, or random data as inputs to a computer program. The program is then monitored for exceptions such as crashes, failing code assertions, or memory leaks.",
            impact = "Uncovers hidden coding errors, logic flaws, and edge-case bugs that normal manual testing might completely miss."
        ),
        GlossaryItem(
            term = "Encryption (At-Rest & In-Transit)",
            definition = "The process of converting readable information into an unreadable format using cryptographic algorithms. 'In-Transit' protects data moving across networks (like the internet), while 'At-Rest' protects stored data on hard drives or cloud servers.",
            impact = "Keeps sensitive client records and proprietary databases completely unreadable to unauthorized parties, even if they physically steal the storage drives or intercept network traffic."
        ),
        GlossaryItem(
            term = "OWASP Top 10",
            definition = "A standard awareness document representing a broad consensus on the most critical security risks to web applications. Maintained by the Open Web Application Security Project, it ranks vulnerabilities like Injection and Broken Authentication.",
            impact = "Provides a globally recognized benchmark for assessing web security, helping developers write code that is inherently resistant to common web attacks."
        ),
        GlossaryItem(
            term = "Multi-Factor Authentication (MFA)",
            definition = "A security technology that requires multiple methods of authentication from independent categories of credentials to verify a user's identity (e.g., a password combined with an authenticator app code).",
            impact = "Blocks over 99.9% of account compromise attacks, ensuring that a stolen password alone is not enough to breach your system."
        )
    )

    // --- Static Mock Data ---
    val services = listOf(
        ServiceItem("Penetration Testing", "Identifying and exploiting security vulnerabilities to strengthen your application defenses.", "bug_report", "Offensive"),
        ServiceItem("Vulnerability Assessment", "Comprehensive digital asset scanning to locate, categorize, and prioritize potential risks.", "security", "Defensive"),
        ServiceItem("Web Application Security", "Deep code and runtime audits focusing on OWASP Top 10 to safeguard enterprise web apps.", "web", "Offensive"),
        ServiceItem("Network Security", "Evaluating firewall rules, internal routers, and packet traffic flows to intercept network-level threats.", "lan", "Defensive"),
        ServiceItem("Cloud Security Hardening", "Analyzing AWS, Google Cloud, and Azure configurations and IAM roles for least-privilege architecture.", "cloud", "Defensive"),
        ServiceItem("Security Compliance Audits", "Evaluating corporate security policies, technical controls, and procedural alignment (SOC2, HIPAA).", "fact_check", "Governance"),
        ServiceItem("Security Awareness Training", "Simulated phishing attacks and hands-on workshops to build a cyber-resilient workforce culture.", "school", "Governance"),
        ServiceItem("Incident Response Strategy", "Developing and testing battle-ready contain, eliminate, and recover frameworks for active breaches.", "crisis_alert", "Defensive"),
        ServiceItem("API Security Testing", "Exposing API authorization flows, validating token handshakes, and auditing REST/GraphQL nodes.", "api", "Offensive"),
        ServiceItem("Strategic Security Consulting", "Tailored security planning, technology evaluation, threat modeling, and virtual CISO services.", "forum", "Governance")
    )

    val skills = listOf(
        SkillItem("Ethical Hacking", 0.95f, "Offensive"),
        SkillItem("OWASP Top 10", 0.98f, "Offensive"),
        SkillItem("Kali Linux", 0.92f, "Tools"),
        SkillItem("Burp Suite", 0.94f, "Tools"),
        SkillItem("Metasploit", 0.88f, "Tools"),
        SkillItem("Nmap & Wireshark", 0.90f, "Tools"),
        SkillItem("Linux Administration", 0.91f, "Infrastructure"),
        SkillItem("Python (Scripting)", 0.90f, "Infrastructure"),
        SkillItem("Digital Forensics", 0.82f, "Defensive"),
        SkillItem("Threat Hunting", 0.89f, "Defensive"),
        SkillItem("SIEM Integration", 0.85f, "Defensive")
    )

    val projects = listOf(
        ProjectItem(
            title = "Fintech API Penetration Audit",
            objective = "Audit an enterprise fintech payment API handling millions of dollars in transaction volume.",
            methodology = "Black-box testing, mobile SDK reverse engineering, rate-limiting stress, and broken object-level authorization (BOLA) fuzzing.",
            outcome = "Uncovered two critical IDOR flaws letting attackers inspect foreign statements. Remediated in 24 hours, preventing potential exposure of 100K+ clients.",
            tags = listOf("Penetration Testing", "Fintech", "OWASP API")
        ),
        ProjectItem(
            title = "HIPAA Compliance & Cloud Hardening",
            objective = "Secure a multi-tenant healthcare SaaS running on complex AWS cloud architecture.",
            methodology = "IAM architecture mapping, continuous compliance tracking with AWS Security Hub, and database-level field encryption configuration.",
            outcome = "Patched zero-trust policy drifts, reduced AWS perimeter attack surface by 75%, and obtained SOC2 and HIPAA audit clearance with zero findings.",
            tags = listOf("Cloud Security", "AWS", "HIPAA")
        ),
        ProjectItem(
            title = "Smart Electric Meter Firmware Analysis",
            objective = "Evaluate critical hardware endpoints of national smart electric meters for tampering vectors.",
            methodology = "Firmware binary dumping via JTAG interfaces, memory stack-overflow exploitation, and analysis of cryptographic handshakes.",
            outcome = "Identified buffer overflow vulnerabilities in smart node responses. Provided patch recommendation implemented across 12,000 smart network terminals.",
            tags = listOf("IoT Security", "Hardware Audits", "Reverse Engineering")
        )
    )

    val certifications = listOf(
        CertificationItem("OSCP", "Offensive Security", "0xFF00E5FF", "OS-102948"),
        CertificationItem("CISSP", "ISC²", "0xFF00B0FF", "CISSP-748392"),
        CertificationItem("CEH Master", "EC-Council", "0xFF2979FF", "ECC-112938"),
        CertificationItem("AWS Security Specialty", "Amazon Web Services", "0xFF00E676", "AWS-SEC-928")
    )

    val testimonials = listOf(
        TestimonialItem(
            quote = "Marcus delivered exceptional, thorough results. His technical report was detailed yet completely actionable. Our executive board was thoroughly impressed.",
            author = "Sarah Jenkins",
            company = "Vanguard Wealth",
            authorTitle = "CTO"
        ),
        TestimonialItem(
            quote = "Unmatched depth in security consulting. Helped us achieve HIPAA compliance in record time while hardening our AWS server instances securely.",
            author = "Dr. David Carter",
            company = "MedLink Software",
            authorTitle = "Director of Security"
        ),
        TestimonialItem(
            quote = "His simulated phishing exercises and workshops completely transformed our employee risk score, dropping click-through rates from 19% to less than 1%.",
            author = "Liam Thorne",
            company = "CloudCore Systems",
            authorTitle = "VP of Engineering"
        )
    )

    val blogPosts = listOf(
        BlogItem(
            id = "1",
            title = "Tactical Remediation: Fixing OWASP API #1",
            excerpt = "How modern companies can build swift authorization verification interceptors to fully prevent IDOR attacks.",
            readTime = "5 min read",
            tag = "API Security",
            publishedDate = "June 22, 2026",
            fullText = """
                In modern web architectures, Broken Object-Level Authorization (BOLA/IDOR) continues to reign as the most critical and common API vulnerability. This occurs when an endpoint accepts user-supplied identifiers (such as UUIDs or integer IDs) to access resources without validating if the current session actually owns that resource.
                
                The mistake is simple: relying on a database query like `SELECT * FROM invoices WHERE id = :id` instead of enforcing tenant isolation.
                
                ### How to Remediate:
                
                1. **Inject Global Context Helpers**: Implement interceptor filters at the gateway level that crosscheck resource tenants against active, cryptographic JWT claims.
                
                2. **Use Secure GUIDs/UUIDs**: Replace auto-incrementing sequential integers with cryptographically random UUID v4 values. This prevents attackers from guessing adjacent IDs.
                
                3. **Enforce Isolation in Queries**: Always append tenant constraints to active database scripts. For example: `SELECT * FROM invoices WHERE id = :id AND user_id = :current_user_id`.
                
                Implementing these defensive checkpoints at the early architecture phase prevents catastrophic data exposures.
            """.trimIndent()
        ),
        BlogItem(
            id = "2",
            title = "Zero-Trust Cloud Governance Architecture",
            excerpt = "A technical checklist for configuring least-privilege IAM policies on AWS, Google Cloud, and Azure environments.",
            readTime = "8 min read",
            tag = "Cloud Security",
            publishedDate = "May 14, 2026",
            fullText = """
                Cloud systems are inherently dynamic. Standard network boundaries (firewalls) are no longer sufficient. Identity is the new perimeter.
                
                A Zero-Trust framework assumes that threats exist both inside and outside the network. Therefore, every request must be authenticated, authorized, and continuously validated before granting access.
                
                ### Key AWS IAM Configuration Principles:
                
                *   **Eliminate Wildcards (*)**: Never attach policies containing `"Action": "*"` or `"Resource": "*"` to users or long-lived keys.
                
                *   **Adopt Role-Based Access Control (RBAC)**: Assign temporary IAM Roles instead of long-term credentials. Ensure that EC2, ECS, or Lambda services utilize IAM Instance Profiles rather than hardcoded environment variables.
                
                *   **Enable Multi-Factor Authentication (MFA)**: Strictly enforce MFA across all IAM administrative structures and console logins.
                
                *   **Enforce IP Restriction Clauses**: Supplement IAM resource permissions with a strict subnet condition clause, ensuring administrative calls can only originate from the corporate VPN or safe IP range.
            """.trimIndent()
        ),
        BlogItem(
            id = "3",
            title = "Securing GraphQL: Eliminating Denial of Service",
            excerpt = "Defensive strategies against malicious queries, deep nested structures, and query cost exhaustion.",
            readTime = "6 min read",
            tag = "Web Apps",
            publishedDate = "April 29, 2026",
            fullText = """
                Unlike REST, where each request maps to a pre-defined server-side resource, GraphQL permits users to design custom queries. While highly flexible, this opens dangerous vectors for Denial of Service (DoS) attacks.
                
                An attacker can craft a recursive, deeply-nested query that forces the server to make thousands of database lookup queries (known as the N+1 problem).
                
                ### Implementation Recommendations:
                
                1. **Query Depth Limiting**: Configure middleware to parse and reject query trees that exceed a specific nesting threshold (e.g., maximum depth of 5).
                
                2. **Query Cost Analysis**: Assign static 'costs' to fields (e.g., simple scalar is 1, array fetch is 10) and reject requests whose cumulative score exceeds a safe threshold (e.g., maximum cost of 100).
                
                3. **Rate Limiting at Resolver Level**: Use Redis-backed sliding window algorithms to throttle intensive database fetch requests.
            """.trimIndent()
        )
    )

    // --- Interactive State Management ---
    
    // Contact form state
    private val _submissions = MutableStateFlow<List<ContactSubmission>>(emptyList())
    val submissions: StateFlow<List<ContactSubmission>> = _submissions.asStateFlow()

    // Global Search Query state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Booking states
    private val _bookings = MutableStateFlow<List<BookingItem>>(emptyList())
    val bookings: StateFlow<List<BookingItem>> = _bookings.asStateFlow()

    // AI Chat History
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage("advisor", "Aegis security core initiated. Ask me anything about threat hunting, code vulnerabilities, or penetration testing.", getCurrentTimeString())
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    // Selected booking calendar states
    private val _selectedDate = MutableStateFlow<Calendar>(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) })
    val selectedDate: StateFlow<Calendar> = _selectedDate.asStateFlow()

    private val _selectedTimeSlot = MutableStateFlow("10:00 AM")
    val selectedTimeSlot: StateFlow<String> = _selectedTimeSlot.asStateFlow()

    val timeSlots = listOf("09:00 AM", "10:00 AM", "11:00 AM", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM")

    // --- Actions ---

    fun changeBookingDate(daysOffset: Int) {
        val nextDate = Calendar.getInstance()
        nextDate.add(Calendar.DAY_OF_YEAR, daysOffset)
        _selectedDate.value = nextDate
    }

    fun selectTimeSlot(slot: String) {
        _selectedTimeSlot.value = slot
    }

    fun submitBooking(name: String, email: String, service: String): Boolean {
        if (name.isBlank() || email.isBlank() || !email.contains("@")) return false
        
        val dateString = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US).format(_selectedDate.value.time)
        val newBooking = BookingItem(
            id = java.util.UUID.randomUUID().toString().take(6),
            dateString = dateString,
            timeSlot = _selectedTimeSlot.value,
            clientName = name,
            clientEmail = email,
            serviceRequested = service
        )

        _bookings.update { it + newBooking }
        return true
    }

    fun submitContact(name: String, email: String, message: String): Boolean {
        if (name.isBlank() || email.isBlank() || message.isBlank()) return false
        
        val timeStamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val submission = ContactSubmission(
            id = java.util.UUID.randomUUID().toString().take(6),
            name = name,
            email = email,
            message = message,
            timestamp = timeStamp
        )

        _submissions.update { it + submission }
        return true
    }

    fun clearSubmissions() {
        _submissions.value = emptyList()
    }

    fun clearBookings() {
        _bookings.value = emptyList()
    }

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        
        val userMsg = ChatMessage("user", text, getCurrentTimeString())
        _chatMessages.update { it + userMsg }

        // Trigger AI advisor response using the Gemini REST Service
        _isChatLoading.value = true
        viewModelScope.launch {
            // Build simple context array from last 4 messages to preserve flow
            val history = _chatMessages.value.takeLast(5).dropLast(1).map {
                Content(parts = listOf(Part(text = it.text)))
            }

            val responseText = GeminiClient.getCyberSecurityAdvice(text, history)
            
            _chatMessages.update { 
                it + ChatMessage("advisor", responseText, getCurrentTimeString()) 
            }
            _isChatLoading.value = false
        }
    }

    private fun getCurrentTimeString(): String {
        return SimpleDateFormat("HH:mm", Locale.US).format(Date())
    }
}
